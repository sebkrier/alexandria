"""
LiteLLM-based unified AI completion module.
Provides a single interface for all AI providers (Anthropic, OpenAI, Google).
"""

import json
import logging
import re
from typing import TypeVar

import litellm
from pydantic import BaseModel

from app.ai.base import (
    AIProvider,
    CategoryInfo,
    CategorySuggestion,
    CategoryStructure,
    DocumentMetadata,
    SubcategoryAssignment,
    Summary,
    TagSuggestion,
    TaxonomyChangesSummary,
    TaxonomyOptimizationResult,
)
from app.ai.prompts import (
    CATEGORY_SYSTEM_PROMPT,
    CATEGORY_USER_PROMPT,
    EXTRACT_SUMMARY_PROMPT,
    METADATA_EXTRACTION_SYSTEM_PROMPT,
    METADATA_EXTRACTION_USER_PROMPT,
    QUESTION_SYSTEM_PROMPT,
    QUESTION_USER_PROMPT,
    SUMMARY_SYSTEM_PROMPT,
    TAGS_SYSTEM_PROMPT,
    TAGS_USER_PROMPT,
    TAXONOMY_OPTIMIZATION_SYSTEM_PROMPT,
    TAXONOMY_OPTIMIZATION_USER_PROMPT,
    format_categories_for_prompt,
    truncate_text,
)

logger = logging.getLogger(__name__)

# Type variable for generic response model
T = TypeVar("T", bound=BaseModel)

# LiteLLM model prefixes for different providers
PROVIDER_PREFIXES = {
    "anthropic": "anthropic/",
    "openai": "",  # OpenAI models don't need a prefix
    "google": "gemini/",
}

# Available models per provider (for UI display)
# Updated January 2026 - reflects latest model releases
PROVIDER_MODELS = {
    "anthropic": {
        "claude-opus-4-5-20251101": "Claude Opus 4.5 (Most capable)",
        "claude-sonnet-4-5-20250929": "Claude Sonnet 4.5 (Recommended)",
        "claude-haiku-4-5-20251101": "Claude Haiku 4.5 (Fastest)",
    },
    "openai": {
        "gpt-5.2": "GPT-5.2 (Latest)",
        "gpt-5.1": "GPT-5.1",
        "gpt-4.1": "GPT-4.1",
        "o3-mini": "o3-mini (Reasoning)",
    },
    "google": {
        "gemini-3.0-pro": "Gemini 3.0 Pro (Most capable)",
        "gemini-3.0-flash": "Gemini 3.0 Flash (Fast)",
        "gemini-2.5-pro": "Gemini 2.5 Pro",
        "gemini-2.5-flash": "Gemini 2.5 Flash",
    },
}


async def complete(
    messages: list[dict],
    api_key: str,
    model: str,
    provider: str,
    temperature: float = 0.3,
    max_tokens: int = 2000,
) -> str:
    """
    Universal completion using LiteLLM.

    Args:
        messages: List of message dicts with 'role' and 'content'
        api_key: User's decrypted API key
        model: Model ID (e.g., 'claude-sonnet-4-20250514')
        provider: Provider name (e.g., 'anthropic', 'openai', 'google')
        temperature: Sampling temperature
        max_tokens: Maximum tokens in response

    Returns:
        Response content as string
    """
    # Build the full model name with provider prefix
    prefix = PROVIDER_PREFIXES.get(provider, "")
    full_model = f"{prefix}{model}"

    # Set the API key for LiteLLM
    # LiteLLM expects specific env var names, but we can pass directly
    response = await litellm.acompletion(
        model=full_model,
        messages=messages,
        api_key=api_key,
        temperature=temperature,
        max_tokens=max_tokens,
    )

    return response.choices[0].message.content


async def complete_stream(
    messages: list[dict],
    api_key: str,
    model: str,
    provider: str,
    temperature: float = 0.3,
    max_tokens: int = 2000,
):
    """
    Streaming completion using LiteLLM.

    Yields chunks of the response as they arrive.
    """
    from typing import AsyncGenerator

    prefix = PROVIDER_PREFIXES.get(provider, "")
    full_model = f"{prefix}{model}"

    response = await litellm.acompletion(
        model=full_model,
        messages=messages,
        api_key=api_key,
        temperature=temperature,
        max_tokens=max_tokens,
        stream=True,
    )

    async for chunk in response:
        if chunk.choices and chunk.choices[0].delta.content:
            yield chunk.choices[0].delta.content


def _extract_json(text: str) -> dict | list:
    """Extract JSON from model response, handling markdown code blocks."""
    # Try to find JSON in code blocks first
    code_block_match = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
    if code_block_match:
        text = code_block_match.group(1)

    text = text.strip()

    # Find the start of JSON
    start_idx = -1
    for i, char in enumerate(text):
        if char in "{[":
            start_idx = i
            break

    if start_idx == -1:
        raise ValueError(f"No JSON found in response: {text[:200]}")

    # Find matching end
    bracket_stack = []
    end_idx = start_idx
    for i in range(start_idx, len(text)):
        char = text[i]
        if char in "{[":
            bracket_stack.append(char)
        elif char == "}" and bracket_stack and bracket_stack[-1] == "{":
            bracket_stack.pop()
            if not bracket_stack:
                end_idx = i
                break
        elif char == "]" and bracket_stack and bracket_stack[-1] == "[":
            bracket_stack.pop()
            if not bracket_stack:
                end_idx = i
                break

    json_str = text[start_idx : end_idx + 1]
    return json.loads(json_str)


class LiteLLMProvider(AIProvider):
    """
    Universal AI provider using LiteLLM.
    Supports Anthropic, OpenAI, and Google models through a unified interface.
    """

    def __init__(self, api_key: str, model_id: str, provider_name: str = "anthropic"):
        """
        Initialize the LiteLLM provider.

        Args:
            api_key: User's decrypted API key
            model_id: Model ID (e.g., 'claude-sonnet-4-20250514')
            provider_name: Provider name ('anthropic', 'openai', 'google')
        """
        self.api_key = api_key
        self.model_id = model_id
        self._provider_name = provider_name

    @property
    def provider_name(self) -> str:
        return self._provider_name

    async def _complete(
        self,
        system: str,
        user: str,
        max_tokens: int = 2000,
        temperature: float = 0.3,
    ) -> str:
        """Internal completion helper."""
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]
        return await complete(
            messages=messages,
            api_key=self.api_key,
            model=self.model_id,
            provider=self._provider_name,
            temperature=temperature,
            max_tokens=max_tokens,
        )

    async def summarize(
        self,
        text: str,
        title: str | None = None,
        source_type: str | None = None,
    ) -> Summary:
        """Generate a structured summary."""
        user_prompt = EXTRACT_SUMMARY_PROMPT.format(
            title=title or "Untitled",
            source_type=source_type or "article",
            content=truncate_text(text),
        )

        try:
            markdown_content = await self._complete(
                system=SUMMARY_SYSTEM_PROMPT,
                user=user_prompt,
                max_tokens=3000,
            )
            return Summary.from_markdown(markdown_content, title)
        except Exception as e:
            logger.error(f"LiteLLM summarization failed: {e}")
            raise

    async def extract_metadata(
        self,
        text: str,
    ) -> DocumentMetadata:
        """Extract document title and authors using AI."""
        # Only send the first part of the document (title/authors are at the start)
        content_for_extraction = text[:8000]

        user_prompt = METADATA_EXTRACTION_USER_PROMPT.format(
            content=content_for_extraction,
        )

        try:
            content = await self._complete(
                system=METADATA_EXTRACTION_SYSTEM_PROMPT,
                user=user_prompt,
                max_tokens=500,
                temperature=0.1,  # Low temperature for factual extraction
            )
            json_data = _extract_json(content)

            return DocumentMetadata(
                title=json_data.get("title", "Untitled"),
                authors=json_data.get("authors", []),
            )
        except Exception as e:
            logger.error(f"LiteLLM metadata extraction failed: {e}")
            # Return empty metadata on failure - don't block the pipeline
            return DocumentMetadata(title="Untitled", authors=[])

    async def suggest_tags(
        self,
        text: str,
        summary: str | None = None,
        existing_tags: list[str] | None = None,
    ) -> list[TagSuggestion]:
        """Suggest tags for the article."""
        existing_tags_context = ""
        if existing_tags:
            existing_tags_context = f"Existing tags in library: {', '.join(existing_tags)}\nPrefer using existing tags when appropriate."

        user_prompt = TAGS_USER_PROMPT.format(
            existing_tags_context=existing_tags_context,
            summary=summary or "No summary provided",
            text_excerpt=truncate_text(text, 5000),
        )

        try:
            content = await self._complete(
                system=TAGS_SYSTEM_PROMPT,
                user=user_prompt,
                max_tokens=1000,
            )
            json_data = _extract_json(content)

            if isinstance(json_data, list):
                return [TagSuggestion(**tag) for tag in json_data]
            return []
        except Exception as e:
            logger.error(f"LiteLLM tag suggestion failed: {e}")
            raise

    async def suggest_category(
        self,
        text: str,
        summary: str | None = None,
        categories: list[dict] | None = None,
    ) -> CategorySuggestion:
        """Suggest category placement."""
        categories_str = "No categories defined yet."
        if categories:
            categories_str = format_categories_for_prompt(categories)

        user_prompt = CATEGORY_USER_PROMPT.format(
            categories=categories_str,
            summary=summary or "No summary provided",
            text_excerpt=truncate_text(text, 3000),
        )

        try:
            content = await self._complete(
                system=CATEGORY_SYSTEM_PROMPT,
                user=user_prompt,
                max_tokens=500,
            )
            json_data = _extract_json(content)

            # Handle both old format (category_name/parent_category) and new format
            if "category" in json_data and isinstance(json_data["category"], str):
                # Old format - convert to new
                json_data = {
                    "category": CategoryInfo(
                        name=json_data.get(
                            "parent_category", json_data.get("category", "Uncategorized")
                        ),
                        is_new=json_data.get("is_new_category", False),
                    ),
                    "subcategory": CategoryInfo(
                        name=json_data.get("category_name", json_data.get("category")),
                        is_new=json_data.get(
                            "is_new_subcategory", json_data.get("is_new_category", False)
                        ),
                    ),
                    "confidence": json_data.get("confidence", 0.8),
                    "reasoning": json_data.get("reasoning", ""),
                }
                return CategorySuggestion(**json_data)

            return CategorySuggestion(**json_data)
        except Exception as e:
            logger.error(f"LiteLLM category suggestion failed: {e}")
            raise

    async def answer_question(
        self,
        question: str,
        context: str,
    ) -> str:
        """Answer a question using provided context."""
        user_prompt = QUESTION_USER_PROMPT.format(
            question=question,
            context=context,
        )

        try:
            return await self._complete(
                system=QUESTION_SYSTEM_PROMPT,
                user=user_prompt,
                max_tokens=2000,
            )
        except Exception as e:
            logger.error(f"LiteLLM question answering failed: {e}")
            raise

    async def answer_question_stream(
        self,
        question: str,
        context: str,
    ):
        """Stream answer to a question using provided context."""
        user_prompt = QUESTION_USER_PROMPT.format(
            question=question,
            context=context,
        )

        messages = [
            {"role": "system", "content": QUESTION_SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ]

        async for chunk in complete_stream(
            messages=messages,
            api_key=self.api_key,
            model=self.model_id,
            provider=self._provider_name,
            max_tokens=2000,
        ):
            yield chunk

    async def health_check(self) -> bool:
        """Check if the API key is valid."""
        try:
            await self._complete(
                system="You are a helpful assistant.",
                user="Hi",
                max_tokens=10,
            )
            return True
        except Exception as e:
            logger.error(f"LiteLLM health check failed: {e}")
            return False

    async def optimize_taxonomy(
        self,
        articles: list[dict],
        current_taxonomy: list[dict] | None = None,
    ) -> TaxonomyOptimizationResult:
        """
        Analyze the entire library and propose an optimal category structure.

        Args:
            articles: List of article dicts with 'id', 'title', 'summary', 'current_category'
            current_taxonomy: Current category structure (if any)

        Returns:
            TaxonomyOptimizationResult with proposed structure and changes
        """
        # Format articles for the prompt
        articles_lines = []
        for article in articles:
            current_cat = article.get("current_category", "Uncategorized")
            if article.get("current_subcategory"):
                current_cat = f"{current_cat} → {article['current_subcategory']}"
            articles_lines.append(
                f'- [{article["id"]}] "{article["title"]}" (currently: {current_cat})\n'
                f"  Summary: {truncate_text(article.get('summary', 'No summary'), 300)}"
            )

        articles_summary = "\n\n".join(articles_lines)

        # Format current taxonomy
        current_taxonomy_str = "No existing categories"
        if current_taxonomy:
            current_taxonomy_str = format_categories_for_prompt(current_taxonomy)

        user_prompt = TAXONOMY_OPTIMIZATION_USER_PROMPT.format(
            article_count=len(articles),
            articles_summary=articles_summary,
            current_taxonomy=current_taxonomy_str,
        )

        try:
            # Use higher max_tokens for this complex task
            content = await self._complete(
                system=TAXONOMY_OPTIMIZATION_SYSTEM_PROMPT,
                user=user_prompt,
                max_tokens=4000,
                temperature=0.3,
            )
            json_data = _extract_json(content)

            # Parse the response into our structured format
            taxonomy = []
            for cat_data in json_data.get("taxonomy", []):
                subcategories = []
                for sub_data in cat_data.get("subcategories", []):
                    subcategories.append(
                        SubcategoryAssignment(
                            name=sub_data.get("name", ""),
                            article_ids=sub_data.get("article_ids", []),
                            description=sub_data.get("description", ""),
                        )
                    )
                taxonomy.append(
                    CategoryStructure(
                        category=cat_data.get("category", ""),
                        subcategories=subcategories,
                    )
                )

            changes = json_data.get("changes_summary", {})
            changes_summary = TaxonomyChangesSummary(
                new_categories=changes.get("new_categories", []),
                new_subcategories=changes.get("new_subcategories", []),
                merged=changes.get("merged", []),
                split=changes.get("split", []),
                reorganized=changes.get("reorganized", []),
            )

            return TaxonomyOptimizationResult(
                taxonomy=taxonomy,
                changes_summary=changes_summary,
                reasoning=json_data.get("reasoning", ""),
            )
        except Exception as e:
            logger.error(f"LiteLLM taxonomy optimization failed: {e}")
            raise
