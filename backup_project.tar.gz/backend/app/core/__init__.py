# Core application utilities and constants
